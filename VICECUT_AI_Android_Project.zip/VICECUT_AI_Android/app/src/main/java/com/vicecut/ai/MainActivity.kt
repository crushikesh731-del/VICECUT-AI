package com.vicecut.ai

import android.content.ContentResolver
import android.content.Context
import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.OpenableColumns
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.media3.common.MediaItem
import androidx.media3.common.MimeTypes
import androidx.media3.transformer.EditedMediaItem
import androidx.media3.transformer.Transformer
import androidx.media3.transformer.ProgressHolder
import androidx.media3.transformer.ExportResult
import androidx.media3.transformer.Composition
import androidx.media3.transformer.ExportException
import java.io.File
import java.util.Locale

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { ViceCutScreen(this) }
    }
}


@Composable
private fun ViceCutScreen(context: Context) {
    val bg = Color(0xFF0B0D12)
    val panel = Color(0xFF171B24)
    val accent = Color(0xFF9D4EDD)
    var selectedUri by remember { mutableStateOf<Uri?>(null) }
    var fileName by remember { mutableStateOf("No video selected") }
    var startText by remember { mutableStateOf("0") }
    var endText by remember { mutableStateOf("") }
    var status by remember { mutableStateOf("Choose a gameplay video to begin.") }
    var progress by remember { mutableStateOf(0f) }
    var busy by remember { mutableStateOf(false) }
    var outputPath by remember { mutableStateOf("") }

    val pickVideo = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        if (uri != null) {
            selectedUri = uri
            fileName = queryName(context.contentResolver, uri) ?: "Selected video"
            val durationMs = readDuration(context, uri)
            endText = if (durationMs > 0) String.format(Locale.US, "%.1f", durationMs / 1000.0) else ""
            startText = "0"
            status = "Video loaded. Enter clip start/end time in seconds."
        }
    }

    fun exportClip() {
        val uri = selectedUri ?: run { status = "Select a video first."; return }
        val startSec = startText.toDoubleOrNull()
        val endSec = endText.toDoubleOrNull()
        if (startSec == null || endSec == null || startSec < 0 || endSec <= startSec) {
            status = "Enter valid start and end seconds (end must be greater than start)."; return
        }
        val folder = File(context.getExternalFilesDir(null), "VICECUT_Clips")
        if (!folder.exists()) folder.mkdirs()
        val out = File(folder, "VICECUT_${System.currentTimeMillis()}.mp4")
        val mediaItem = MediaItem.Builder().setUri(uri).setClippingConfiguration(
            MediaItem.ClippingConfiguration.Builder()
                .setStartPositionMs((startSec * 1000).toLong())
                .setEndPositionMs((endSec * 1000).toLong())
                .build()
        ).build()
        val edited = EditedMediaItem.Builder(mediaItem).build()
        busy = true; progress = 0f; status = "Exporting clip…"
        val transformer = Transformer.Builder(context)
            .setVideoMimeType(MimeTypes.VIDEO_H264)
            .setAudioMimeType(MimeTypes.AUDIO_AAC)
            .addListener(object : Transformer.Listener {
                override fun onCompleted(composition: Composition, exportResult: ExportResult) {
                    busy = false; progress = 1f; outputPath = out.absolutePath
                    status = "Clip exported! File saved inside VICECUT_Clips in app storage."
                }
                override fun onError(composition: Composition, exportResult: ExportResult, exportException: ExportException) {
                    busy = false; status = "Export failed: ${exportException.message ?: "Unsupported video format"}"
                    if (out.exists()) out.delete()
                }
            }).build()
        transformer.start(edited, out.absolutePath)
        val holder = ProgressHolder()
        val handler = Handler(Looper.getMainLooper())
        val poll = object : Runnable {
            override fun run() {
                if (!busy) return
                val state = transformer.getProgress(holder)
                if (state == Transformer.PROGRESS_STATE_AVAILABLE) progress = (holder.progress / 100f).coerceIn(0f, 0.99f)
                handler.postDelayed(this, 500)
            }
        }
        handler.post(poll)
    }


    MaterialTheme(colorScheme = darkColorScheme(primary = accent, background = bg, surface = panel)) {
        Column(Modifier.fillMaxSize().background(bg).verticalScroll(rememberScrollState()).padding(20.dp)) {
            Text("VICECUT", fontSize = 34.sp, fontWeight = FontWeight.Black, color = Color.White)
            Text("AI GAMEPLAY CLIPPER", color = accent, fontWeight = FontWeight.Bold, letterSpacing = 2.sp)
            Spacer(Modifier.height(24.dp))
            Card(colors = CardDefaults.cardColors(containerColor = panel), shape = RoundedCornerShape(18.dp)) {
                Column(Modifier.fillMaxWidth().padding(18.dp)) {
                    Text("CLIP STUDIO", color = Color.White, fontSize = 20.sp, fontWeight = FontWeight.Bold)
                    Spacer(Modifier.height(12.dp))
                    Text("Choose a video from your phone", color = Color.LightGray)
                    Spacer(Modifier.height(12.dp))
                    Button(onClick = { pickVideo.launch("video/*") }, enabled = !busy, modifier = Modifier.fillMaxWidth()) {
                        Text("SELECT GAMEPLAY VIDEO")
                    }
                    Spacer(Modifier.height(8.dp))
                    Text(fileName, color = Color(0xFFB8BBC6), fontSize = 13.sp)
                }
            }
            Spacer(Modifier.height(16.dp))
            Card(colors = CardDefaults.cardColors(containerColor = panel), shape = RoundedCornerShape(18.dp)) {
                Column(Modifier.fillMaxWidth().padding(18.dp)) {
                    Text("TRIM YOUR CLIP", color = Color.White, fontWeight = FontWeight.Bold)
                    Spacer(Modifier.height(12.dp))
                    OutlinedTextField(value = startText, onValueChange = { startText = it }, label = { Text("Start time (seconds)") }, enabled = !busy, modifier = Modifier.fillMaxWidth())
                    OutlinedTextField(value = endText, onValueChange = { endText = it }, label = { Text("End time (seconds)") }, enabled = !busy, modifier = Modifier.fillMaxWidth())
                    Spacer(Modifier.height(12.dp))
                    Button(onClick = { exportClip() }, enabled = selectedUri != null && !busy, modifier = Modifier.fillMaxWidth()) {
                        Text(if (busy) "EXPORTING…" else "EXPORT CLIP")
                    }
                    if (busy) { Spacer(Modifier.height(12.dp)); LinearProgressIndicator(progress = { progress }, modifier = Modifier.fillMaxWidth()) }
                }
            }
            Spacer(Modifier.height(16.dp))
            Card(colors = CardDefaults.cardColors(containerColor = panel), shape = RoundedCornerShape(18.dp)) {
                Column(Modifier.fillMaxWidth().padding(18.dp)) {
                    Text("STATUS", color = accent, fontWeight = FontWeight.Bold)
                    Spacer(Modifier.height(6.dp))
                    Text(status, color = Color.White)
                    if (outputPath.isNotBlank()) { Spacer(Modifier.height(8.dp)); Text("Saved to app storage:\n$outputPath", color = Color.LightGray, fontSize = 12.sp) }
                }
            }
            Spacer(Modifier.height(16.dp))
            Text("Free • On-device export • No account required", color = Color.Gray, fontSize = 12.sp, modifier = Modifier.align(Alignment.CenterHorizontally))
            Spacer(Modifier.height(10.dp))
            Text("Note: This starter build trims manually selected time ranges. Automatic AI highlight detection and 9:16 reframing are planned for a later version.", color = Color(0xFFB5B5B5), fontSize = 12.sp)
        }
    }
}


private fun queryName(resolver: ContentResolver, uri: Uri): String? =
    resolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use { c ->
        if (c.moveToFirst()) c.getString(0) else null
    }

private fun readDuration(context: Context, uri: Uri): Long {
    return try {
        val retriever = android.media.MediaMetadataRetriever()
        retriever.setDataSource(context, uri)
        val ms = retriever.extractMetadata(android.media.MediaMetadataRetriever.METADATA_KEY_DURATION)?.toLongOrNull() ?: 0L
        retriever.release(); ms
    } catch (_: Exception) { 0L }
}
