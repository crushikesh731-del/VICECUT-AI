# VICECUT AI Android starter (APK build project)

This is a starter Android app for VICECUT AI. Version 1 can pick a video from Android's file picker, trim a user-entered time range, export MP4, and show the app-private output location. It does **not** yet automatically detect highlights, add subtitles, or crop to 9:16.


## Easiest build: GitHub Actions (free tier availability/limits apply)
1. Create/sign in to GitHub and make a new repository named `VICECUT-AI`.
2. Upload the contents of this project folder to the repository (the `.github/workflows/android.yml` file must be included).
3. Open the repository's **Actions** tab.
4. Select **Build VICECUT AI APK**, click **Run workflow**, then **Run workflow**.
5. Wait for the run to finish successfully, open that run, and scroll to **Artifacts**.
6. Download `VICECUT-AI-debug-apk` and unzip it. The APK is `app-debug.apk`.
7. Transfer the APK to your Android phone and tap it to install. If prompted, permit installation from that specific source, then install. Turn the permission off again after installation if desired.

## Build locally (Android Studio)
- Install Android Studio and open this folder as a project.
- Allow Gradle sync to complete, then choose **Build > Build APK(s)**.
- Output is typically `app/build/outputs/apk/debug/app-debug.apk`.

## Exported clips
The app stores exported files in its app-specific external files folder under `VICECUT_Clips`. Android may not expose this folder directly in every file manager. A future version should add a Save-to-device/MediaStore option.

## Requirements
- Android 8.0+ (API 26+)
- Gradle 8.x compatible environment; project uses Android Gradle Plugin 8.7.3 and Java 17

## Current limitations
- Manual trimming only (start/end time in seconds)
- No AI highlight analysis yet
- No automatic 9:16 crop yet
- No subtitle generation yet
- Output is app-specific storage; no gallery-save flow yet
